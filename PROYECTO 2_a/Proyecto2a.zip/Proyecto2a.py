tablero = [['' for fila in range(8)] for columna in range(8)]

piezas_n = int(input("Ingrese el número de piezas: "))
for _ in range(piezas_n):
    tipo_pieza = input("Ingrese el tipo de pieza: ")
    color = input("Color de la pieza: ")
    posicion = input("Posición dentro del tablero: ")
    fila = int(posicion[1]) - 1
    columna = ord(posicion[0]) - ord('a')
if fila in range(8) and columna in range(8) and not tablero[fila][columna]:
        tablero[fila][columna] = f"{tipo_pieza} {color}"
else:
        print("La casilla está ocupada, ingrese otra")
        exit()


torre_posicion = input("Posicion de la torre dentro del tablero: ")
color = input("Color de la torre: ")
fila = int(torre_posicion[1]) - 1
columna = ord(torre_posicion[0]) - ord('a')
if fila in range(8) and columna in range(8) and not tablero[fila][columna]:
    tablero[fila][columna] = 'torre'
else:
    print("La casilla está ocupada, ingrese otra")
    exit()


torre_m = []

for i in range(columna + 1, 8):
    if tablero[fila][i] == '':
        torre_m.append((fila, i, 'vacía'))
    else:
        torre_m.append((fila, i, tablero[fila][i]))
        break
for i in range(columna - 1, -1, -1):
    if tablero[fila][i] == '':
        torre_m.append((fila, i, 'vacía'))
    else:
        torre_m.append((fila, i, tablero[fila][i]))
        break


for i in range(fila + 1, 8):
    if tablero[i][columna] == '':
        torre_m.append((i, columna, 'vacía'))
    else:
        torre_m.append((i, columna, tablero[i][columna]))
        break
for i in range(fila - 1, -1, -1):
    if tablero[i][columna] == '':
        torre_m.append((i, columna, 'vacía'))
    else:
        torre_m.append((i, columna, tablero[i][columna]))
        break

print("Tablero:")
for fila in tablero:
    print(" ".join(pieza if pieza else '□' for pieza in fila))
    
print("Posibles movimientos de la torre:")
for movimiento in torre_m:
    fila, columna,contenido = movimiento
    letra_columna = chr(ord('a') + columna)
    print(f"Posición: {letra_columna}{fila + 1}, Contenido: {contenido}")